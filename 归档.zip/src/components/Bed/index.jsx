import React from 'react'
import bed from '../../public/images/bed.png'
import './bed.css'


const Monkey = () => (
        <div className="bg_bed" >
            <img src={bed} />
        </div>

)

export default Monkey
