const config = {
    chain: 'http://121.196.200.225:1337',
    privateKey: 'a3b33668e5be5b31e08f5695a1efb21bd0c2e8607d06a5b55021585883be93ac',
    contractAddress: '0x57f512188445bd07187031206EA441Bf8051D813',
}



module.exports = config
