import React from 'react'
import quilt from '../../public/images/quilt.png'
import './quilt.css'


const Quilt = () => (
        <div className="bg_quilt" >
            <img src={quilt} />
        </div>

)

export default Quilt
